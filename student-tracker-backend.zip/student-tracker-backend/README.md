# 🎓 Student Tracker — Backend Setup (Step 1)

## 📁 Folder Structure

```
student-tracker-backend/       ← ROOT folder (your project)
│
├── package.json               ← Lists all npm packages needed
├── .env                       ← Secret config (MongoDB URL, Port)
├── .env.example               ← Template to share (no secrets)
├── .gitignore                 ← Tells Git what NOT to upload
│
└── backend/                   ← All backend code lives here
    ├── server.js              ← ⭐ MAIN FILE — starts the server
    │
    ├── config/
    │   └── db.js              ← MongoDB connection logic
    │
    ├── models/
    │   └── Student.js         ← MongoDB schema (data structure)
    │
    ├── routes/
    │   └── testRoutes.js      ← Defines URL paths → /api/test
    │
    └── controllers/
        └── testController.js  ← Logic that runs for each route
```

---

## ⚡ Quick Start — Run in 3 Steps

### Step 1 — Install packages
```bash
npm install
```
This reads `package.json` and downloads: express, mongoose, cors, dotenv, nodemon

---

### Step 2 — Setup MongoDB

**Option A — Use MongoDB Atlas (FREE, no install needed):**
1. Go to https://www.mongodb.com/atlas
2. Create a free account → Create a free cluster
3. Click **Connect** → **Connect your application**
4. Copy the connection string (looks like: `mongodb+srv://...`)
5. Open `.env` file, replace the MONGO_URI value with your string

**Option B — Local MongoDB (must be installed):**
- The `.env` file already has `mongodb://localhost:27017/studenttracker`
- Just make sure MongoDB service is running on your PC

---

### Step 3 — Start the server
```bash
# Development mode (auto-restarts when you save changes):
npm run dev

# OR normal mode:
npm start
```

---

## ✅ Test That Everything Works

After starting the server, open your browser and go to:

| URL | What you should see |
|-----|---------------------|
| `http://localhost:5000` | Welcome message with endpoint list |
| `http://localhost:5000/api/test` | `{ "success": true, "message": "API working" }` |
| `http://localhost:5000/api/status` | Server status info |

---

## 🔍 What Each File Does

### `backend/server.js`
The **heart** of the backend. It:
- Loads environment variables from `.env`
- Connects to MongoDB
- Creates the Express app
- Sets up middleware (CORS, JSON parsing)
- Mounts routes
- Starts listening on PORT 5000

### `backend/config/db.js`
Contains the `connectDB()` function that uses Mongoose to connect to MongoDB. If connection fails, it stops the whole app.

### `backend/routes/testRoutes.js`
Maps URLs to controller functions:
- `GET /api/test` → calls `testAPI`
- `GET /api/status` → calls `getStatus`

### `backend/controllers/testController.js`
Contains the actual logic:
- `testAPI` — sends `{ message: "API working" }`
- `getStatus` — sends server information

### `backend/models/Student.js`
Mongoose schema — defines what a Student document looks like in MongoDB. Will be expanded in Step 2.

---

## 🧠 How It All Connects

```
Browser/Frontend
      ↓  HTTP Request: GET /api/test
      
server.js (receives request)
      ↓  app.use("/api", testRoutes)
      
testRoutes.js (matches the path)
      ↓  router.get("/test", testAPI)
      
testController.js (runs the logic)
      ↓  res.json({ message: "API working" })
      
Browser/Frontend receives response
```

---

## ❌ Common Errors & Fixes

| Error | Cause | Fix |
|-------|-------|-----|
| `Cannot find module 'express'` | npm install not run | Run `npm install` |
| `MongoServerError: bad auth` | Wrong MongoDB password | Check MONGO_URI in `.env` |
| `EADDRINUSE: port 5000` | Port already in use | Change PORT in `.env` to 5001 |
| `Error: connect ECONNREFUSED` | MongoDB not running | Start MongoDB or use Atlas |
| `CORS error in browser` | Origin not in allowed list | Add your frontend URL to cors() in server.js |

---

## 📦 Packages Used

| Package | Purpose |
|---------|---------|
| `express` | Web framework — handles HTTP requests/responses |
| `mongoose` | ODM — connects to MongoDB, defines schemas |
| `cors` | Allows frontend (different port) to call this backend |
| `dotenv` | Reads `.env` file into `process.env` |
| `nodemon` | Dev tool — auto-restarts server on file save |

---

## 🚀 Next Steps (Step 2)
- Add User authentication (Register/Login with JWT)
- Expand Student model with all fields
- Add CRUD routes for Students
- Add attendance and marks routes
