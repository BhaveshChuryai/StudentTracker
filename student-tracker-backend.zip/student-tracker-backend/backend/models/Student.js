// =============================================
// FILE:  backend/models/Student.js
// PURPOSE: Mongoose Schema for Student data
//
// WHAT IS A MODEL/SCHEMA?
// A Schema defines the SHAPE of data stored
// in MongoDB. Like a blueprint/template.
// A Model is the compiled version of that Schema
// that you use to create/read/update/delete data.
//
// NOTE: This is a placeholder for Step 1.
// Full student fields will be added in Step 2.
// =============================================

// Step 1: Import mongoose
const mongoose = require("mongoose");

// Step 2: Define the Schema (structure of a Student document)
const studentSchema = new mongoose.Schema(
  {
    // Basic fields — more will be added in Step 2
    name: {
      type: String,
      required: [true, "Student name is required"],
      trim: true,
    },

    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true,
    },

    rollNumber: {
      type: String,
      required: [true, "Roll number is required"],
      unique: true,
      trim: true,
    },

    // createdAt and updatedAt are added automatically
    // because we set: { timestamps: true }
  },
  {
    timestamps: true, // Adds createdAt and updatedAt fields automatically
  }
);

// Step 3: Create the Model from the Schema
// mongoose.model("Student", studentSchema) creates a collection
// named "students" in MongoDB (Mongoose pluralizes automatically)
const Student = mongoose.model("Student", studentSchema);

// Step 4: Export the model
module.exports = Student;
