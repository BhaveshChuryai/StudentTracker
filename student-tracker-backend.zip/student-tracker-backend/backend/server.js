// =============================================
// FILE:  backend/server.js
// PURPOSE: Main Express server — entry point
//          of the entire backend application
// =============================================

// ─────────────────────────────────────────
// STEP 1: Load environment variables
// This MUST be the very first line.
// It reads .env file and makes variables
// available via process.env.VARIABLE_NAME
// ─────────────────────────────────────────
require("dotenv").config();

// ─────────────────────────────────────────
// STEP 2: Import required packages
// ─────────────────────────────────────────
const express = require("express"); // Web framework
const cors = require("cors");       // Allows frontend to call this backend
const connectDB = require("./config/db"); // Our MongoDB connection function

// ─────────────────────────────────────────
// STEP 3: Connect to MongoDB
// This runs connectDB() immediately.
// If it fails, the app exits automatically
// (handled inside connectDB with process.exit)
// ─────────────────────────────────────────
connectDB();

// ─────────────────────────────────────────
// STEP 4: Create the Express app
// app is the core object — everything runs on it
// ─────────────────────────────────────────
const app = express();

// ─────────────────────────────────────────
// STEP 5: Setup Middleware
// Middleware runs on EVERY request before
// it reaches your route handlers.
// ─────────────────────────────────────────

// 5a. CORS — Allows your HTML frontend (running on a
//     different port like 5500 or 3000) to call this
//     backend (running on port 5000).
//     Without CORS, the browser blocks the request.
app.use(
  cors({
    origin: [
      "http://localhost:3000",   // React dev server
      "http://localhost:5500",   // VS Code Live Server
      "http://127.0.0.1:5500",  // VS Code Live Server (alternate)
      "http://localhost:8080",   // Other common ports
    ],
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true,
  })
);

// 5b. express.json() — Parses incoming JSON request bodies.
//     Without this, req.body would be undefined.
//     Example: When frontend sends { name: "Aarav" },
//     this middleware makes it available as req.body.name
app.use(express.json());

// 5c. express.urlencoded() — Parses form data (HTML forms)
//     extended: true allows nested objects
app.use(express.urlencoded({ extended: true }));

// ─────────────────────────────────────────
// STEP 6: Import Route files
// ─────────────────────────────────────────
const testRoutes = require("./routes/testRoutes");

// ─────────────────────────────────────────
// STEP 7: Mount Routes
// app.use("/api", testRoutes) means:
// All routes defined in testRoutes will be
// prefixed with /api
// So router.get("/test") becomes GET /api/test
// ─────────────────────────────────────────
app.use("/api", testRoutes);

// ─────────────────────────────────────────
// STEP 8: Root Route
// Just a friendly message at http://localhost:5000
// ─────────────────────────────────────────
app.get("/", (req, res) => {
  res.json({
    message: "🎓 Student Tracker API is running!",
    endpoints: {
      test:   "GET  /api/test",
      status: "GET  /api/status",
    },
    instructions: "Open http://localhost:5000/api/test to verify",
  });
});

// ─────────────────────────────────────────
// STEP 9: 404 Handler
// If no route matched above, send a 404 error.
// This MUST be placed AFTER all other routes.
// ─────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`,
    hint: "Check the URL and try again",
  });
});

// ─────────────────────────────────────────
// STEP 10: Global Error Handler
// Catches any errors thrown inside route
// handlers and sends a clean response.
// The 4-parameter signature (err, req, res, next)
// tells Express this is an error handler.
// ─────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error("❌ Server Error:", err.message);

  res.status(err.status || 500).json({
    success: false,
    message: err.message || "Internal Server Error",
  });
});

// ─────────────────────────────────────────
// STEP 11: Start the Server
// Read PORT from .env (defaults to 5000 if not set)
// ─────────────────────────────────────────
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log("");
  console.log("╔════════════════════════════════════════╗");
  console.log("║      🎓 STUDENT TRACKER BACKEND        ║");
  console.log("╠════════════════════════════════════════╣");
  console.log(`║  ✅ Server running on port ${PORT}          ║`);
  console.log(`║  🌍 URL: http://localhost:${PORT}           ║`);
  console.log(`║  📦 Mode: ${process.env.NODE_ENV}              ║`);
  console.log("╠════════════════════════════════════════╣");
  console.log(`║  TEST:   http://localhost:${PORT}/api/test  ║`);
  console.log(`║  STATUS: http://localhost:${PORT}/api/status║`);
  console.log("╚════════════════════════════════════════╝");
  console.log("");
});
