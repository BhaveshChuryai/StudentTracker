// =============================================
// FILE:  backend/controllers/testController.js
// PURPOSE: Controller functions for test routes
//
// WHAT IS A CONTROLLER?
// A controller is a function that handles what
// happens when someone hits an API endpoint.
// It reads the request and sends back a response.
// =============================================

// @desc    Test that the API is working
// @route   GET /api/test
// @access  Public (anyone can call this)
const testAPI = (req, res) => {
  // res.json() sends back a JSON response
  res.status(200).json({
    success: true,
    message: "API working",
    project: "Student Tracker",
    version: "1.0.0",
    timestamp: new Date().toISOString(),
  });
};

// @desc    Get server status and info
// @route   GET /api/status
// @access  Public
const getStatus = (req, res) => {
  res.status(200).json({
    success: true,
    status: "Server is running",
    environment: process.env.NODE_ENV,
    port: process.env.PORT || 5000,
    database: "MongoDB connected",
    uptime: `${Math.floor(process.uptime())} seconds`,
  });
};

// Export both functions so routes can use them
module.exports = { testAPI, getStatus };
