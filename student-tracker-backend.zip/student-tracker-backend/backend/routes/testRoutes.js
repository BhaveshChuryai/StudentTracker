// =============================================
// FILE:  backend/routes/testRoutes.js
// PURPOSE: Define API routes for testing
//
// WHAT IS A ROUTE?
// A route connects a URL path (like /api/test)
// to a controller function that handles it.
// Think of it like a telephone directory —
// when a call comes to /api/test, forward it
// to the testAPI controller function.
// =============================================

// Step 1: Import express and create a Router
const express = require("express");
const router = express.Router();

// Step 2: Import controller functions
const { testAPI, getStatus } = require("../controllers/testController");

// ─────────────────────────────────────────
// DEFINE ROUTES
// ─────────────────────────────────────────

// Route 1: GET /api/test
// → Calls testAPI function from controller
// → Returns: { success: true, message: "API working" }
router.get("/test", testAPI);

// Route 2: GET /api/status
// → Returns server status information
router.get("/status", getStatus);

// Step 3: Export the router so server.js can use it
module.exports = router;
