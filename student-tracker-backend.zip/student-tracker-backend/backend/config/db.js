// =============================================
// FILE:  backend/config/db.js
// PURPOSE: Connect to MongoDB using Mongoose
// =============================================

// Step 1: Import mongoose (the library that talks to MongoDB)
const mongoose = require("mongoose");

// Step 2: Create the connectDB function
const connectDB = async () => {
  try {
    // Step 3: Connect using the URI from our .env file
    // process.env.MONGO_URI reads the value from .env
    const conn = await mongoose.connect(process.env.MONGO_URI);

    // Step 4: If connection succeeds, print a success message
    // conn.connection.host shows which server we connected to
    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);

  } catch (error) {
    // Step 5: If connection FAILS, print the error and stop the app
    console.error(`❌ MongoDB Connection Error: ${error.message}`);

    // Exit the Node.js process with code 1 (means failure)
    process.exit(1);
  }
};

// Step 6: Export so server.js can use it
module.exports = connectDB;
